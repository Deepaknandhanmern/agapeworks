Vivira AI - WooCommerce Plugin
===============================

Thanks for your interest in Vivira AI.

The packaged plugin release is being finalized. Your details have been
saved, and we'll follow up by email with the installable .zip and setup
instructions shortly.

In the meantime, if you have questions, reach us at hello@agapeworks.in.
